'use strict';
/**
 * OIG Portal server — zero runtime dependencies (Node >= 18).
 *
 *  GET /api/apps    registry + live status of every app (checked server-side on 127.0.0.1)
 *  GET /api/health  liveness of the portal itself
 *  everything else  static SPA from ./public (index.html fallback)
 *
 * Designed to sit behind oig-gate: binds 127.0.0.1 only, so the gate is the single
 * entry point and owns authentication. apps.json is re-read when it changes, so adding
 * an app needs no restart.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const DIR = __dirname;
const CONFIG_FILE = process.env.PORTAL_CONFIG || path.join(DIR, 'apps.json');
const PUBLIC_DIR = path.join(DIR, 'public');
const LOG_FILE = path.join(DIR, 'portal.log');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.txt': 'text/plain; charset=utf-8'
};

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'same-origin',
  'X-Frame-Options': 'DENY',
  'Content-Security-Policy':
    "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
};

function log(event, fields = {}) {
  const line = JSON.stringify({ t: new Date().toISOString(), event, ...fields });
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch { /* logging must never break serving */ }
  if (process.env.PORTAL_VERBOSE) console.log(line);
}

// ---------- config (hot reload on mtime change, last good config kept on error) ----------

let cfgCache = null;
let cfgMtime = 0;

function validateConfig(cfg) {
  if (!cfg || !Array.isArray(cfg.apps) || !Array.isArray(cfg.categories)) throw new Error('apps.json: "apps" and "categories" arrays are required');
  const cats = new Set(cfg.categories.map((c) => c.id));
  const ids = new Set();
  for (const a of cfg.apps) {
    if (!a.id || !a.name || !Number.isInteger(a.port)) throw new Error(`apps.json: app needs id, name, integer port: ${JSON.stringify(a)}`);
    if (ids.has(a.id)) throw new Error(`apps.json: duplicate id "${a.id}"`);
    if (!cats.has(a.category)) throw new Error(`apps.json: app "${a.id}" has unknown category "${a.category}"`);
    ids.add(a.id);
  }
  return cfg;
}

function getConfig() {
  let mtime = 0;
  try { mtime = fs.statSync(CONFIG_FILE).mtimeMs; } catch {}
  if (!cfgCache || mtime !== cfgMtime) {
    try {
      const text = fs.readFileSync(CONFIG_FILE, 'utf8').replace(/^﻿/, '');
      cfgCache = validateConfig(JSON.parse(text));
      cfgMtime = mtime;
      healthCache.clear();
      log('config_loaded', { apps: cfgCache.apps.length });
    } catch (e) {
      log('config_error', { error: e.message });
      if (!cfgCache) throw e; // no good config yet: fail loudly at startup
    }
  }
  return cfgCache;
}

// ---------- health checks ----------

const healthCache = new Map(); // id -> { at, result }

function probe(app, timeoutMs) {
  const started = Date.now();
  return new Promise((resolve) => {
    const req = http.request(
      { host: '127.0.0.1', port: app.port, path: app.healthPath || '/', method: 'GET', timeout: timeoutMs, headers: { 'User-Agent': 'oig-portal-health' } },
      (res) => {
        res.resume(); // drain, we only need the status line
        // Any HTTP answer below 500 means the process is up (401/404 included).
        const code = res.statusCode || 0;
        resolve({ status: code < 500 ? 'up' : 'degraded', httpStatus: code, latencyMs: Date.now() - started });
      }
    );
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', (e) => resolve({ status: 'down', error: e.code || e.message, latencyMs: Date.now() - started }));
    req.end();
  });
}

async function statusOf(app, cfg) {
  const ttl = ((cfg.health && cfg.health.cacheSeconds) || 15) * 1000;
  const hit = healthCache.get(app.id);
  if (hit && Date.now() - hit.at < ttl) return hit.result;
  const result = await probe(app, (cfg.health && cfg.health.timeoutMs) || 2500);
  result.checkedAt = new Date().toISOString();
  const prev = hit && hit.result.status;
  if (prev && prev !== result.status) log('status_change', { app: app.id, from: prev, to: result.status });
  healthCache.set(app.id, { at: Date.now(), result });
  return result;
}

function linkFor(app, cfg) {
  if (app.url) return app.url;
  if (app.access === 'local') return null; // bound to 127.0.0.1 on the VM, not reachable from devices
  const base = (cfg.links && cfg.links.directBase) || '';
  return base ? `${base}:${app.port}/` : null;
}

async function appsPayload() {
  const cfg = getConfig();
  const apps = await Promise.all(cfg.apps.map(async (a) => ({
    id: a.id, name: a.name, category: a.category, description: a.description || '',
    port: a.port, access: a.access || 'direct', env: a.env || 'prod',
    url: linkFor(a, cfg), health: await statusOf(a, cfg)
  })));
  return { generatedAt: new Date().toISOString(), categories: cfg.categories, apps };
}

// ---------- http ----------

function send(res, code, body, headers = {}) {
  res.writeHead(code, { ...SECURITY_HEADERS, ...headers });
  res.end(body);
}

function sendJson(res, code, obj) {
  send(res, code, JSON.stringify(obj), { 'Content-Type': MIME['.json'], 'Cache-Control': 'no-store' });
}

function serveStatic(req, res, pathname) {
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { return send(res, 400, 'Bad request'); }
  let file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR)) return send(res, 403, 'Forbidden'); // path traversal guard
  let stat;
  try { stat = fs.statSync(file); } catch {}
  if (!stat || stat.isDirectory()) {
    if (path.extname(rel)) return send(res, 404, 'Not found'); // missing asset: real 404
    file = path.join(PUBLIC_DIR, 'index.html'); // SPA fallback
  }
  const ext = path.extname(file);
  const immutable = file.includes(`${path.sep}assets${path.sep}`); // vite hashed files
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'Not found');
    send(res, 200, req.method === 'HEAD' ? '' : data, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': immutable ? 'public, max-age=31536000, immutable' : 'no-cache'
    });
  });
}

const server = http.createServer(async (req, res) => {
  const { pathname } = new URL(req.url, 'http://localhost');
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed', { Allow: 'GET, HEAD' });
  try {
    if (pathname === '/api/health') return sendJson(res, 200, { ok: true, uptimeSec: Math.round(process.uptime()) });
    if (pathname === '/api/apps') return sendJson(res, 200, await appsPayload());
    if (pathname.startsWith('/api/')) return sendJson(res, 404, { error: 'not_found' });
    return serveStatic(req, res, pathname);
  } catch (e) {
    log('request_error', { path: pathname, error: e.message });
    return sendJson(res, 500, { error: 'internal' });
  }
});

const cfg = getConfig();
const host = process.env.PORTAL_HOST || (cfg.listen && cfg.listen.host) || '127.0.0.1';
const port = Number(process.env.PORTAL_PORT || (cfg.listen && cfg.listen.port) || 4990);
server.listen(port, host, () => {
  log('started', { host, port, apps: cfg.apps.length });
  console.log(`oig-portal listening on http://${host}:${port}`);
});

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { log('stopped', { sig }); server.close(() => process.exit(0)); });
