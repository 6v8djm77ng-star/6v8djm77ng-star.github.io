# Rollback: stops and removes the portal task. Leaves C:\apps\oig-portal on disk (delete by hand if wanted).
$task = 'OIG Portal'
if (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue) {
  Stop-ScheduledTask -TaskName $task
  Unregister-ScheduledTask -TaskName $task -Confirm:$false
  'Removed scheduled task.'
} else { 'Task not found - nothing to do.' }
