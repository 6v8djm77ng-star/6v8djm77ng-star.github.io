# Installs OIG Portal on the VM. Safe to re-run (idempotent). Touches nothing else.
#   - copies server\ into C:\apps\oig-portal (apps.json is kept if it already exists)
#   - registers a Scheduled Task "OIG Portal" that starts at boot and restarts on failure
#   - starts it and checks http://127.0.0.1:4990/api/health
# Run in an elevated PowerShell from the unzipped folder:  .\deploy\install.ps1
$ErrorActionPreference = 'Stop'
$src    = Join-Path $PSScriptRoot '..\server' | Resolve-Path
$dest   = 'C:\apps\oig-portal'
$node   = 'C:\apps\runtime\node\node.exe'
$task   = 'OIG Portal'

if (-not (Test-Path $node)) { throw "Node not found at $node" }
if (Get-NetTCPConnection -State Listen -LocalPort 4990 -ErrorAction SilentlyContinue) {
  $owner = (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue)
  if (-not $owner) { throw 'Port 4990 is already used by another process. Change listen.port in apps.json first.' }
}

New-Item -ItemType Directory -Force -Path $dest | Out-Null
$keepConfig = Test-Path "$dest\apps.json"
if ($keepConfig) { Copy-Item "$dest\apps.json" "$dest\apps.json.bak-$(Get-Date -f yyyyMMdd-HHmmss)" }

if (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue) { Stop-ScheduledTask -TaskName $task; Start-Sleep 2 }

Remove-Item "$dest\public" -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item "$src\server.js" $dest -Force
Copy-Item "$src\public" $dest -Recurse -Force
if (-not $keepConfig) { Copy-Item "$src\apps.json" $dest }

$action   = New-ScheduledTaskAction -Execute $node -Argument 'server.js' -WorkingDirectory $dest
$trigger  = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable
Register-ScheduledTask -TaskName $task -Action $action -Trigger $trigger -Settings $settings -User 'SYSTEM' -RunLevel Highest -Force | Out-Null
Start-ScheduledTask -TaskName $task
Start-Sleep 3

try {
  $h = Invoke-RestMethod 'http://127.0.0.1:4990/api/health' -TimeoutSec 5
  "OK - portal is up (uptime $($h.uptimeSec)s). Open locally: http://127.0.0.1:4990"
} catch { "FAILED - portal did not answer. Check $dest\portal.log" }
